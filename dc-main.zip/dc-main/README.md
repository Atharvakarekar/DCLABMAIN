# dc

TO run these file follows this *STEPS*:

- Lab bheith jaate toh aaj yeh padhna nhi padta **GAWAAR** 😒

![](https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExOGpiemlsZHFsMW1kcHMxbWc1cHJ5aWhiaXNwem4ybTBucnE3bWd5YSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/26BGIqWh2R1fi6JDa/giphy.gif)

